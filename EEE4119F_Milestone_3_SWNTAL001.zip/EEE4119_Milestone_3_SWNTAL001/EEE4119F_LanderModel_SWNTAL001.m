%In this segment of code I to modelled the system
%State variables and generalized coordinates
syms x y th dx dy ddx ddy dth ddth 
q = [x; y; th];
dq = [dx; dy; dth];
ddq = [ddx; ddy; ddth];

%Landers parameters
syms m l1 l2 F1 F2 Izz g dL

%% Calculation of g (Gravitational accecleration)
% Im going to use Newtons 2nd law to calulcate g also refered to as a
% the acceleration. I set F1 and F2 to 0 and then extract the vertical
% velocity. I divide the velocity by time to give me the acceleration. 
% Fnet = ma -> ma = - mg so cancel m on both sides therfore g = a. If 
% the forces were non-zero but equal then ma = F1 + F2 - mg. ddy used 
% to get a. Since the sensors have noise, I took 3 tests, no thrust, 
% 1000N each and 10000N each and then averaged a value for g.
t0 = 15.2450;
dy0 = -130.718473312420;
g0 = -130.718473312420/15.2450; %velocity/time
g1000 = (4000*(-126.8414/15.709) - 2*1000)/(4000); %(ma - Fnet)/m
g10000 = (4000*(-84.4051006778055/23.61) - 2*10000)/(4000); %(ma - Fnet)/m

gf = (g0 + g1000 + g10000)/3;
%g = -8.5746m.s-2

%% Calculation of Izz and dL
% The moment of inertia of a rigid body determines the bodies behaviour
% under rotation. The equation that models this behaviour is Mn = I(alpha)
% analogous to Fn = ma. Since the rate of change of the angular velocity is
% measured and I is unknown, I apply a single force for simplicity to one 
% thruster which causes the body to rotate. With this force and the 
% perpendicular distance to the COM, the moment can be calculated. Since
% the moment is known, Izz can be found.

% I applied a 1000N force to the left thruster causing the lander to rotate
% clockwise hence the negative direction. The perpendicular distance to
% the COM from the thruster is the width/2 as the COM is in the
% horizontally central coordinate. The value for ddth was found in
% simulation to be -0.048.

Izzf = -1000*(6/2)/-0.048; %Fr/alpha
%Izzf = 62500 (Final Value)

% Izz is the moment of inertia about the bodies mass center so we
% can use the parallel axis theorem to get I at the geometric center 
% of the rectangle. Since I at geometric center is given by 
% 1/12 * m * (a^2 + b^2) the value dL can be solved from the parallel axis 
% theorem. I = Ic + mdL^2.

%I = 1/12 * m * (l1^2 + l2^2);
Ic = 1/12 * 4000 * (6^2 + 8^2); 

%dL = sqrt((Izz-Ic)/m);
dLf = sqrt((Izzf-Ic)/4000);
%dL final value is 2.7

% There is no noise on the angle sensor so one recording is sufficient

%% Rotations
R01 = Rotz(th);
R10 = transpose(R01);

%% Mass Positions
%Lander COM in frame 1 which is the landers frame
r_Lander_0 = [x; y; 0];
%Landing spot in the inertial frame
r_Final_0 = [0; 0; 0]; 
%Lander COM in the inertial frame


%% Generalized Forces
%Forces in the landers frame (The frame origin is placed at COM)
F_1 = [0; F1; 0];
F_2 = [0; F2; 0];

%Forces in the inertial frame
F_1_0 = R10 * F_1;
F_2_0 = R10 * F_2;

%Position of Force 1 in frame 1
rF1_1 = [-l1/2; -(dL + l2/2); 0];
%Position of Force 1 in inertial frame done by rotating force to inertia
%and adding the base (x;y;0) offset
rF1_0 = r_Lander_0 + R10 * rF1_1;
%Position of Force 2 in frame 1
rF2_1 = [l1/2; -(dL + l2/2); 0];
%Position of Force 2 in inertial frame done by rotating force to inertia
%and adding the base (x;y;0) offset
rF2_0 = r_Lander_0 + R10 * rF2_1;

%drj/dqi computed
partX1 = diff(rF1_0, x);
partY1 = diff(rF1_0, y);
partTh1 = diff(rF1_0, th);

partX2 = diff(rF2_0, x);
partY2 = diff(rF2_0, y);
partTh2 = diff(rF2_0, th);

%Qi = sum of F1 dot dri/dqi and F2 dot dri/dqi 
Qx = transpose(F_1_0) * partX1 + transpose(F_2_0) * partX2;
Qy = transpose(F_1_0) * partY1 + transpose(F_2_0) * partY2;
Qth = transpose(F_1_0) * partTh1 + transpose(F_2_0) * partTh2;

Q = simplify([Qx; Qy; Qth]);
%% Mass Velocities
dr_Lander = jacobian(r_Lander_0,q) * dq;

%% Angular Velocity
w01_1 = [0;0;dth];

%% Kinetic Energy
%Sum of kinetic energy and potential energy
T_tot = simplify(0.5 * m * transpose(dr_Lander) * dr_Lander + 0.5 * transpose(w01_1) * Izz * w01_1);
%% Potential Energy
% I decided to use the base of the lander as a reference point for potential
% energy. This is arbitrary aslong as the reference point is kept constant.
V_tot = simplify(m * g * y);
%% Define Mass Matrix
M = hessian(T_tot,dq);
%% Define Mass Matrix Deriv
dM = sym(zeros(length(M),length(M)));
for i=1:length(M)
    for j=1:length(M)
        dM(i,j) = jacobian(M(i,j),q)*dq;
    end
end
dM = simplify(dM);

%% Define Gravity Matrix
G = simplify(jacobian(V_tot,q));
%% Define Coriolis Matrix
C = dM*dq - transpose(jacobian(T_tot,q));
C = simplify(C);

%% Define Manipulator Equation
ManipulatorEqn = M*ddq + C + transpose(G) == Q;

%End result
ddq = solve(ManipulatorEqn, ddq);

%% End of Milestone 1

%% Linearized Matrices
Ml = [[m; 0; 0], [0; m; 0], [0; 0; Izz]];
Gl = [0; m*g; 0];
Cl = [0; 0; 0];
Ql = [-th*(F1 + F2); F1 + F2; -l1*(F1 - F2)/2];
%% Equations of Motion
u = [F1;F2];
%EOM = simplify(Ml\(Ql - Cl - transpose(Gl)))
EOM = simplify(M\(Q - C - transpose(G)));
dyn =  [EOM; dq];
A = jacobian(dyn, [dq.', q.']);
A = subs(A, [dq.', q.', u.'], [0,0,0,0,0,0,m*g/2,m*g/2]);
B = jacobian(dyn, [u.']);
B = subs(B, [dq.',q.',u.'],[0,0,0,0,0,0,m*g/2,m*g/2]);

g_sub = 8.5746;
m_sub = 4000;
l1_sub = 6;
Izz_sub = 62500;
A = double(subs(A, g, g_sub));
B = double(subs(B, [m,l1,Izz], [m_sub,l1_sub,Izz_sub]));
C = eye(6);
D = [];

%% State Space
Qlqr(1,1) = 1000;    %dx
Qlqr(2,2) = 0.00005;    %dy
Qlqr(3,3) = 1000;    %dth
Qlqr(4,4) = 1000;    %x
Qlqr(5,5) = 1000000000;    %y
Qlqr(6,6) = 1000;    %th

%{
    K = 1.0e+4*[0.0292    0.125   -1.2286    0.0050    0.025  -0.7245
               -0.0292    0.125    1.2286   -0.0050    0.025   0.7245]; 
%}
R = eye(2);

Klqr = lqr(A, B, Qlqr, R)

%% make an animation
% You'll probably only want to run this twice - once right now, and again
% after your controller works :)
sim('LanderModelV2_SWNTAL001');  % tell simulink to simulate the model
make_animation(x.time, x.signals.values, y.signals.values, th.signals.values, dy.signals.values, 10)

% note the .time and .signals.values syntax for unpacking a Structure with
% Time

%% check whether you succeeded
safely_landed(y.signals.values, dy.signals.values, th.signals.values)

%% make line plots
% this runs your simulation multiple times and plots some useful
% quantities. You'll probably want to use this a lot
 make_line_plots(3, 'LanderModelV2_SWNTAL001')
%% Helper Functions
function A = Rotz(th)
    A = [cos(th)   sin(th) 0;... 
         -sin(th)  cos(th) 0;...
         0        0        1];
end