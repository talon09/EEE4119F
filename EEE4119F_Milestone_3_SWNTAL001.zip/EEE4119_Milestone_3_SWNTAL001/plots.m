% Data
%{
speed1_rpm = [1788, 1766, 1753, 1740, 1732];
torque1 = [0.2, 0.7, 1, 1.2, 1.3];
voltage1 = [162, 163, 164, 164, 165];

speed2_rpm = [2382, 2361, 2343, 2336, 2330];
torque2 = [0.2, 0.7, 1, 1.2, 1.4];
voltage2 = [201, 202, 202, 202, 203];

speed3_rpm = [2979, 2958, 2947, 2934, 2927];
torque3 = [0.2, 0.7, 1, 1.2, 1.4];
voltage3 = [227, 228, 228, 226, 228];

speed4_rpm = [3570, 3547, 3528, 3518, 3507];
torque4 = [0.2, 0.7, 1, 1.2, 1.4];
voltage4 = [244, 245, 243, 243, 243];

t5 = [0.45, 0.44, 0.46, 0.2];
s5 = [185, 248, 309, 372];
v5 = [165, 202, 227, 244];
% Convert speed from rpm to rad/s
speed1 = speed1_rpm * 2 * pi / 60;
speed2 = speed2_rpm * 2 * pi / 60;
speed3 = speed3_rpm * 2 * pi / 60;
speed4 = speed4_rpm * 2 * pi / 60;

% Plot torque vs speed and voltage vs speed for all datasets on the same plot
figure;

% Plot torque vs speed and voltage vs speed for datasets 1-4 on the same plot
figure;

% Plot torque vs speed for datasets 1-4
yyaxis left;
plot(speed1, torque1, '-', 'DisplayName', 'Torque 1');
hold on;
plot(speed2, torque2, '-', 'DisplayName', 'Torque 2');
plot(speed3, torque3, '-', 'DisplayName', 'Torque 3');
plot(speed4, torque4, '-', 'DisplayName', 'Torque 4');
plot(s5, t5, '-', 'DisplayName', 'Torque 5');
ylabel('Torque');
ylim([0, max([torque1, torque2, torque3, torque4, t5])]); % Set y-axis limit for torque

% Plot voltage vs speed for datasets 1-4
yyaxis right;
plot(speed1, voltage1, '--', 'DisplayName', 'Voltage 1');
hold on;
plot(speed2, voltage2, '--', 'DisplayName', 'Voltage 2');
plot(speed3, voltage3, '--', 'DisplayName', 'Voltage 3');
plot(speed4, voltage4, '--', 'DisplayName', 'Voltage 4');
ylabel('Voltage');
ylim([0, max([voltage1, voltage2, voltage3, voltage4, v5])]); % Set y-axis limit for voltage

% Label the plot
xlabel('Speed (rad/s)');
title('Torque and Voltage vs Speed');
grid on;
legend('Location', 'best');
%}

speed1_rpm = [1788, 1766, 1753, 1740, 1732];
torque1 = [0.2, 0.7, 1, 1.2, 1.3];
voltage1 = [162, 163, 164, 164, 165];

speed2_rpm = [2382, 2361, 2343, 2336, 2330];
torque2 = [0.2, 0.7, 1, 1.2, 1.4];
voltage2 = [201, 202, 202, 202, 203];

speed3_rpm = [2979, 2958, 2947, 2934, 2927];
torque3 = [0.2, 0.7, 1, 1.2, 1.4];
voltage3 = [227, 228, 228, 226, 228];

speed4_rpm = [3570, 3547, 3528, 3518, 3507];
torque4 = [0.2, 0.7, 1, 1.2, 1.4];
voltage4 = [244, 245, 243, 243, 243];

recorded_pf_30Hz = [0.18, 0.33, 0.4, 0.45, 0.49];
calculated_pf_30Hz = [0.17, 0.33, 0.41, 0.44, 0.48];
recorded_pf_40Hz = [0.18, 0.35, 0.45, 0.49, 0.52];
calculated_pf_40Hz = [0.18, 0.36, 0.45, 0.48, 0.52];

recorded_pf_50Hz = [0.195, 0.385, 0.49, 0.53, 0.567];
calculated_pf_50Hz = [0.20, 0.383, 0.485, 0.524, 0.569];

recorded_pf_60Hz = [0.252, 0.484, 0.583, 0.625, 0.658];
calculated_pf_60Hz = [0.246, 0.486, 0.585, 0.621, 0.655];

data1 = [173, 175, 183, 191, 194];
data2 = [206, 215, 222, 228, 232];
data3 = [235, 241, 249, 250, 257];
data4 = [220, 225, 233, 237, 242];
figure;
hold on;

plot(speed1_rpm,data1, '-o', 'DisplayName', 'Reactive (30Hz)');
%plot(speed1_rpm, calculated_pf_30Hz, '--o', 'DisplayName', 'Calculated PF (30Hz)');

plot(speed2_rpm, data2, '-o', 'DisplayName', 'Reactive (40Hz)');
%plot(speed2_rpm, calculated_pf_40Hz, '--o', 'DisplayName', 'Calculated PF (40Hz)');

plot(speed3_rpm, data3, '-o', 'DisplayName', 'Reactive (50Hz)');
%plot(speed3_rpm, calculated_pf_50Hz, '--o', 'DisplayName', 'Calculated PF (50Hz)');

plot(speed4_rpm, data4, '-o', 'DisplayName', 'Reactive (60Hz)');
%plot(speed4_rpm, calculated_pf_60Hz, '--o', 'DisplayName', 'Calculated PF (60Hz)');

hold off;

xlabel('Speed (RPM)');
ylabel('Reactive Power');
title('Reactive Power vs Speed');
legend('Location', 'best');
grid on;