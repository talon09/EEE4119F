% outputs done = true if the all requirements are achieved
function [done] = safely_landed(y_com, dy, th)
    done = true;
    
    % the extra distance comes from landing gear of negligible mass
    y_bottom = y_com - 10*cos(th);

    % some margin for error since the simulation stops just after the point
    % where y <= 0
    if ~all(y_bottom(1:end-1) >= -0.5)
        fprintf("The lander somehow went below the surface of the planet: ");
        fprintf("min(y_com) - 10 = %f\n", min(y_bottom))
        done = false;
    end

    if y_bottom(end) > 0.5
        fprintf("The lander didn't actually land: y_bottom(end) = %f\n", y_bottom(end));
        done = false;
    end

    if abs(dy(end)) > 2
        fprintf("The lander hit the ground at a high speed: ");
        fprintf("dy(end) = %f\n", dy(end));
        done = false;
    end

    % theta may be eg. 2pi = 0 rad, so take the remainder
    if rad2deg(abs(rem(th(end), 2*pi))) > 10
        fprintf("The lander should land almost vertically: ");
        fprintf("rad2deg(th(end)) = %f\n", rad2deg(th(end)));
        done = false;
    end
end
